olga-compute_pgen --humanTRA -i pgen/TRA_seqs.txt -o pgen/TRA_seqs.pgen.txt
olga-compute_pgen --humanTRB -i pgen/TRB_seqs.txt -o pgen/TRB_seqs.pgen.txt